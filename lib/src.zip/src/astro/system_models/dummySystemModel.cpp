#include "tudat/astro/system_models/engineModel.h"

// FILE INCLUDED FOR COMPATIBILITY (MUST HAVE .CPP FILE ON SOME SYSTEMS)
