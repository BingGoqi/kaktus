#include "tudat/astro/ephemerides/compositeEphemeris.h"

namespace tudat
{

namespace ephemerides
{

template class CompositeEphemeris< double, double >;


} // namespace ephemerides

} // namespace tudat
