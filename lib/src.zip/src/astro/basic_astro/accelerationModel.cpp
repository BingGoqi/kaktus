#include "tudat/astro/basic_astro/accelerationModel.h"

namespace tudat
{  
namespace basic_astrodynamics
{

template class AccelerationModel< Eigen::Vector3d >;

} // namespace basic_astrodynamics

} // namespace tudat
