#include "tudat/astro/propagators/nBodyCowellStateDerivative.h"

namespace tudat
{

namespace propagators
{

template class NBodyCowellStateDerivative< double, double >;


} // namespace propagators

} // namespace tudat

