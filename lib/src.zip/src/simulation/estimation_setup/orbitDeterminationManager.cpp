#include "tudat/simulation/estimation_setup/orbitDeterminationManager.h"

namespace tudat
{

namespace simulation_setup
{


template class OrbitDeterminationManager< double, double >;

}

}
