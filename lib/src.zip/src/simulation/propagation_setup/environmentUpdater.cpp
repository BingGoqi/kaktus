#include "tudat/simulation/propagation_setup/environmentUpdater.h"

namespace tudat
{

namespace propagators
{

template class EnvironmentUpdater< double, double >;


} // namespace propagators

} // namespace tudat

