#include "tudat/math/quadrature/createNumericalQuadrature.h"

namespace tudat
{

namespace numerical_quadrature
{


} // namespace numerical_quadrature

} // namespace tudat

