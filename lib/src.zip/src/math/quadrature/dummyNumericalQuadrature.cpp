#include "tudat/math/quadrature/numericalQuadrature.h"

// FILE INCLUDED FOR COMPATIBILITY (MUST HAVE .CPP FILE ON SOME SYSTEMS)
