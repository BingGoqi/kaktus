# cowell-startup
An example program about self-startup of Cowell integrator, and a method to decrease round-off errors.
