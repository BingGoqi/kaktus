#include "kaktus/astor/Body.h"
namespace kaktus::astor
{
	void Body::getStateToBody(Body& b, double time, Eigen::Vector6d& state)
	{
		Body& s = eph.getCentralBody;
		//while()
	}
}