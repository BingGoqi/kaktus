#include <iostream>
int main()
{
	std::cout << "07734";
	return 0;
}