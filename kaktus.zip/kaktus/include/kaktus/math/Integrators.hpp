#ifndef KAKTUS_INTEGRATORS_H
#define KAKTUS_INTEGRATORS_H
namespace kaktus::Intergators
{

}
#endif // !KAKTUS_INTEGRATORS_H